# Images Directory

Place documentation images here:

- hero-light.svg
- hero-dark.svg
- revenue-inbox-dashboard.png
- hubspot-sidebar-icon.png
- chrome-add-extension.png
- chrome-pin-extension.png
- eazybe-sidebar.png

Use relative paths in documentation: `/images/filename.png`
